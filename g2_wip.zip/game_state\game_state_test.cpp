#include "game_state.h"
#include "save_data.h"
#include "save_storage.h"
#include "Preferences.h"
#include <cassert>
#include <cstdio>
#include <limits>

using namespace PokemonGame;
using GameSaveStorage::LoadResult;

std::vector<uint8_t> encode(const GameSave& save) {
  std::vector<uint8_t> bytes(SAVE_MAX_SIZE);
  size_t size = 0;
  assert(serialize(save, bytes.data(), bytes.size(), size));
  bytes.resize(size);
  return bytes;
}

// Independent CRC reference also checks protected semantic/header mutations.
void updateCrc(std::vector<uint8_t>& bytes) {
  uint32_t crc = 0xffffffffu;
  for (size_t i = 0; i < bytes.size(); ++i) {
    if (i >= 14 && i < 18) continue;
    crc ^= bytes[i];
    for (unsigned bit = 0; bit < 8; ++bit)
      crc = (crc & 1) ? (crc >> 1) ^ 0xedb88320u : crc >> 1;
  }
  crc = ~crc;
  for (unsigned i = 0; i < 4; ++i) bytes[14 + i] = static_cast<uint8_t>(crc >> (8 * i));
}

void codecTests() {
  GameSave save;
  save.state = createNewGame();
  assert(isValidState(save.state));
  assert(partner(save.state)->instanceId == 1 && save.state.progress.nextInstanceId == 2);
  assert(partner(save.state)->level == 5 && partner(save.state)->currentHp == 18);
  assert(partner(save.state)->friendship == 70 && partner(save.state)->exp == 0);
  assert(dexContains(save.state.pokedex.seen, 25));
  assert(dexContains(save.state.pokedex.caught, 25));
  assert(!dexContains(save.state.pokedex.shinyCaught, 25));
  assert(!dexContains(save.state.pokedex.seen, 0));
  assert(!dexContains(save.state.pokedex.seen, 1026));
  registerCaught(save.state.pokedex, 1025, true);
  assert(dexContains(save.state.pokedex.shinyCaught, 1025));

  // All fields, 16-bit move IDs, gender/shiny packing, three unique party IDs.
  save.sequence = 0x12345678;
  save.state.party.count = 3;
  for (unsigned i = 0; i < 3; ++i) {
    save.state.party.members[i] = save.state.party.members[0];
    save.state.party.members[i].instanceId = i + 1;
    save.state.party.members[i].level = static_cast<uint8_t>(5 + i);
    save.state.party.members[i].exp = 0x12340000u + i;
    save.state.party.members[i].currentHp = static_cast<uint16_t>(i);
    save.state.party.members[i].gender = static_cast<Gender>(i);
  }
  save.state.party.members[1].shiny = true;
  registerCaught(save.state.pokedex, 25, true);
  save.state.progress.nextInstanceId = 4;
  save.state.progress.deskPetId = 2;
  save.state.progress.ballTier = 2;
  save.state.progress.masterBallCount = 7;
  save.state.progress.playTimeSeconds = 987654;
  auto bytes = encode(save);
  assert(bytes.size() == SAVE_MAX_SIZE);
  assert(bytes[0] == 'P' && bytes[4] == 2 && bytes[5] == 0);
  assert(bytes[6] == 0x78 && bytes[7] == 0x56 && bytes[8] == 0x34 && bytes[9] == 0x12);
  GameSave decoded;
  assert(deserialize(bytes.data(), bytes.size(), decoded) == DecodeResult::Ok);
  assert(encode(decoded) == bytes);
  assert(partner(decoded.state)->gender == Gender::Female && partner(decoded.state)->shiny);
  size_t written = 999;
  uint8_t tiny[3];
  assert(!serialize(save, tiny, sizeof(tiny), written) && written == 0);

  // Every single-bit corruption and every truncated length must be rejected.
  for (size_t i = 0; i < bytes.size(); ++i) {
    for (unsigned bit = 0; bit < 8; ++bit) {
      auto broken = bytes; broken[i] ^= static_cast<uint8_t>(1u << bit);
      assert(deserialize(broken.data(), broken.size(), decoded) == DecodeResult::Invalid);
      assert(encode(decoded) == bytes); // No partial application.
    }
    assert(deserialize(bytes.data(), i, decoded) == DecodeResult::Invalid);
  }
  auto broken = bytes; broken.push_back(0);
  assert(deserialize(broken.data(), broken.size(), decoded) == DecodeResult::Invalid);
  broken = bytes; broken[4] = 3; updateCrc(broken);
  assert(deserialize(broken.data(), broken.size(), decoded) == DecodeResult::UnsupportedVersion);
  broken = bytes; broken[32] = 4; updateCrc(broken); // party count
  assert(deserialize(broken.data(), broken.size(), decoded) == DecodeResult::Invalid);
  broken = bytes; broken[53] = 0; updateCrc(broken); // first level
  assert(deserialize(broken.data(), broken.size(), decoded) == DecodeResult::Invalid);
  broken = bytes; broken[56] = 0x80; updateCrc(broken); // reserved flags
  assert(deserialize(broken.data(), broken.size(), decoded) == DecodeResult::Invalid);

  GameState invalid = createNewGame();
  invalid.party.members[0].currentHp = 65535; assert(!isValidState(invalid));
  invalid = createNewGame(); invalid.progress.deskPetId = 99; assert(!isValidState(invalid));
  invalid = createNewGame(); invalid.progress.nextInstanceId = 1; assert(!isValidState(invalid));
  invalid = createNewGame(); invalid.party.members[0].formId = 1; assert(!isValidState(invalid));
  invalid = createNewGame(); invalid.party.members[0].moves[0] = 999; assert(!isValidState(invalid));
  invalid = createNewGame(); invalid.pokedex.seen[3] = 0; assert(!isValidState(invalid));
  invalid = createNewGame(); invalid.pokedex.seen[128] = 0x80; assert(!isValidState(invalid));
  invalid = createNewGame(); invalid.party.members[1] = invalid.party.members[0];
  invalid.party.count = 2; assert(!isValidState(invalid));
  std::puts("PASS core: stats, IDs, bitsets, roundtrip, corruption, truncation, validation");
}

void storageTests() {
  FakeNvs::reset();
  FakeNvs::data["schedule/existing"] = {1, 2, 3};
  FakeNvs::data["calcache/json"] = {4, 5, 6};
  GameSave save;
  assert(GameSaveStorage::load(save) == LoadResult::Missing);
  save.state = createNewGame();
  assert(GameSaveStorage::save(save) && save.sequence == 1);
  const auto first = FakeNvs::data.at("pokemon_g1/save_a");
  save.state.party.members[0].exp = 123;
  save.state.party.members[0].friendship = 88;
  save.state.party.members[0].currentHp = 7;
  assert(GameSaveStorage::save(save) && save.sequence == 2);
  assert(FakeNvs::data.at("pokemon_g1/save_a") == first);
  GameSave rebooted;
  assert(GameSaveStorage::load(rebooted) == LoadResult::Loaded);
  assert(rebooted.sequence == 2 && partner(rebooted.state)->exp == 123);
  assert(partner(rebooted.state)->friendship == 88 && partner(rebooted.state)->currentHp == 7);
  const unsigned writes = FakeNvs::writes;
  assert(GameSaveStorage::load(rebooted) == LoadResult::Loaded && FakeNvs::writes == writes);

  // Torn write to inactive A must retain complete B for next boot.
  FakeNvs::partialWrite = true;
  assert(!GameSaveStorage::save(rebooted) && rebooted.sequence == 2);
  FakeNvs::partialWrite = false;
  assert(GameSaveStorage::load(rebooted) == LoadResult::Loaded && rebooted.sequence == 2);
  FakeNvs::corruptWrite = true;
  assert(!GameSaveStorage::save(rebooted));
  FakeNvs::corruptWrite = false;
  assert(GameSaveStorage::load(rebooted) == LoadResult::Loaded && rebooted.sequence == 2);
  assert(GameSaveStorage::save(rebooted) && rebooted.sequence == 3);
  FakeNvs::data["pokemon_g1/save_a"].back() ^= 1;
  assert(GameSaveStorage::load(rebooted) == LoadResult::Loaded && rebooted.sequence == 2);
  FakeNvs::data["pokemon_g1/save_b"].back() ^= 1;
  assert(GameSaveStorage::load(rebooted) == LoadResult::Invalid);
  rebooted = GameSave{}; rebooted.state = createNewGame();
  assert(GameSaveStorage::save(rebooted));
  assert(GameSaveStorage::load(rebooted) == LoadResult::Loaded);

  auto future = encode(rebooted); future[4] = 3; updateCrc(future);
  FakeNvs::data["pokemon_g1/save_b"] = future;
  const auto before = FakeNvs::data;
  assert(GameSaveStorage::load(rebooted) == LoadResult::UnsupportedVersion);
  assert(!GameSaveStorage::save(rebooted) && FakeNvs::data == before);
  FakeNvs::data["pokemon_g1/save_b"].resize(SAVE_MAX_SIZE + 1);
  assert(GameSaveStorage::load(rebooted) == LoadResult::UnsupportedVersion);
  FakeNvs::data.erase("pokemon_g1/save_b");
  FakeNvs::failRead = true;
  assert(GameSaveStorage::load(rebooted) == LoadResult::StorageError);
  assert(!GameSaveStorage::save(rebooted));
  FakeNvs::failRead = false;
  FakeNvs::failOpen = true;
  assert(GameSaveStorage::load(rebooted) == LoadResult::StorageError);
  assert(!GameSaveStorage::save(rebooted));
  FakeNvs::failOpen = false;
  rebooted.sequence = std::numeric_limits<uint32_t>::max();
  FakeNvs::data["pokemon_g1/save_a"] = encode(rebooted);
  assert(GameSaveStorage::load(rebooted) == LoadResult::Loaded);
  assert(!GameSaveStorage::save(rebooted));
  assert(FakeNvs::data.at("schedule/existing") == std::vector<uint8_t>({1, 2, 3}));
  assert(FakeNvs::data.at("calcache/json") == std::vector<uint8_t>({4, 5, 6}));
  std::puts("PASS storage: reboot, A/B recovery, torn write, errors, versions, namespace isolation");
}

// Frozen G1 field order. Deliberately independent of the current serializer.
std::vector<uint8_t> legacyRecord(const GameSave& save) {
  std::vector<uint8_t> bytes = {'P', 'K', 'D', 'G', 1, 0};
  auto append = [&](uint32_t value, unsigned count) {
    for (unsigned i = 0; i < count; ++i) bytes.push_back(static_cast<uint8_t>(value >> (8 * i)));
  };
  append(save.sequence, 4);
  append(15 + save.state.party.count * 24 + 387, 4);
  append(0, 4);
  const auto& progress = save.state.progress;
  append(progress.nextInstanceId, 4); append(progress.deskPetId, 4);
  append(progress.ballTier, 1); append(progress.masterBallCount, 1); append(progress.playTimeSeconds, 4);
  append(save.state.party.count, 1);
  for (uint8_t i = 0; i < save.state.party.count; ++i) {
    const auto& p = save.state.party.members[i];
    append(p.instanceId, 4); append(p.speciesId, 2); append(p.exp, 4); append(p.currentHp, 2);
    for (MoveId move : p.moves) append(move, 2);
    append(p.level, 1); append(p.friendship, 1); append(p.formId, 1);
    append(static_cast<uint8_t>(p.gender) | (p.shiny ? 4u : 0u), 1);
  }
  for (const uint8_t* bits : {save.state.pokedex.seen, save.state.pokedex.caught, save.state.pokedex.shinyCaught})
    bytes.insert(bytes.end(), bits, bits + 129);
  updateCrc(bytes);
  return bytes;
}

void explorationTests() {
  constexpr uint64_t start = 1800000000ULL;
  ExplorationSession session;
  assert(!startExploration(session, TEST_REGION_ID, 0, 15));
  assert(!startExploration(session, TEST_REGION_ID, MIN_EXPLORATION_EPOCH - 1, 15));
  assert(!startExploration(session, 2, start, 15));
  assert(!startExploration(session, TEST_REGION_ID, start, 0));
  assert(!startExploration(session, TEST_REGION_ID, std::numeric_limits<uint64_t>::max(), 15));
  assert(startExploration(session, TEST_REGION_ID, start, 15));
  assert(session.regionId == TEST_REGION_ID && session.startedAtEpoch == start && session.durationSeconds == 15);
  assert(session.status == ExplorationStatus::Exploring);
  assert(!startExploration(session, TEST_REGION_ID, start + 1, 15));
  assert(remainingSeconds(session, start) == 15);
  assert(remainingSeconds(session, start + 3) == 12);
  assert(remainingSeconds(session, start + 14) == 1);
  assert(remainingSeconds(session, start + 15) == 0);
  assert(!updateExploration(session, 0) && !updateExploration(session, start - 1));
  assert(remainingSeconds(session, start - 1) == 15);
  assert(!updateExploration(session, start + 14));

  GameSave save; save.state = createNewGame(); save.state.exploration = session;
  GameSave rebooted;
  auto bytes = encode(save);
  assert(deserialize(bytes.data(), bytes.size(), rebooted) == DecodeResult::Ok);
  assert(encode(rebooted) == bytes);
  assert(!updateExploration(rebooted.state.exploration, 0)); // Offline reboot.
  assert(rebooted.state.exploration.startedAtEpoch == start);
  assert(updateExploration(rebooted.state.exploration, start + 15));
  assert(rebooted.state.exploration.status == ExplorationStatus::Complete);
  assert(!updateExploration(rebooted.state.exploration, start + 9999));
  bytes = encode(rebooted);
  assert(deserialize(bytes.data(), bytes.size(), save) == DecodeResult::Ok);
  assert(save.state.exploration.status == ExplorationStatus::Complete);
  assert(acknowledgeExploration(save.state.exploration));
  assert(save.state.exploration.status == ExplorationStatus::Idle && save.state.exploration.startedAtEpoch == 0);
  assert(!acknowledgeExploration(save.state.exploration));
  // Full 64-bit epochs survive serialization; future duration > 60s is supported.
  assert(startExploration(save.state.exploration, TEST_REGION_ID, 0x123456789ULL, 80));
  bytes = encode(save);
  assert(deserialize(bytes.data(), bytes.size(), rebooted) == DecodeResult::Ok);
  assert(rebooted.state.exploration.startedAtEpoch == 0x123456789ULL);
  assert(remainingSeconds(rebooted.state.exploration, 0x123456789ULL + 1) == 79);
  // Correct CRC does not bypass exploration field validation.
  for (size_t offset : {size_t(0), size_t(1), size_t(3), size_t(11)}) {
    auto invalid = bytes;
    const size_t position = bytes.size() - EXPLORATION_RECORD_SIZE;
    if (offset == 0) invalid[position] = 9;
    if (offset == 1) invalid[position + 1] = 2;
    if (offset == 3) for (size_t i = 0; i < 8; ++i) invalid[position + 3 + i] = 0;
    if (offset == 11) for (size_t i = 0; i < 4; ++i) invalid[position + 11 + i] = 0;
    updateCrc(invalid);
    assert(deserialize(invalid.data(), invalid.size(), rebooted) == DecodeResult::Invalid);
  }
  std::puts("PASS exploration: start, elapsed, offline/rollback, completion once, ack, 64-bit persistence");
}

void migrationTests() {
  FakeNvs::reset();
  GameSave original; original.state = createNewGame(); original.sequence = 41;
  original.state.party.count = 3;
  for (uint8_t i = 0; i < 3; ++i) {
    original.state.party.members[i] = original.state.party.members[0];
    auto& p = original.state.party.members[i];
    p.instanceId = 10 + i; p.level = 5 + i; p.exp = 4567 + i;
    p.friendship = 91 + i; p.currentHp = 3 + i;
    p.gender = i == 1 ? Gender::Female : Gender::Male;
    p.shiny = i == 2;
  }
  original.state.progress.deskPetId = 11; original.state.progress.nextInstanceId = 13;
  original.state.progress.ballTier = 2; original.state.progress.masterBallCount = 3;
  original.state.progress.playTimeSeconds = 987;
  registerCaught(original.state.pokedex, 25, true);
  registerCaught(original.state.pokedex, 1025, true);
  const auto g1 = legacyRecord(original);
  assert(g1.size() == 492);
  FakeNvs::data["pokemon_g1/save_a"] = g1;
  GameSave loaded;
  assert(GameSaveStorage::load(loaded) == LoadResult::Loaded && loaded.saveVersion == 1);
  assert(loaded.state.exploration.status == ExplorationStatus::Idle);
  auto migrated = loaded; migrated.saveVersion = SAVE_VERSION;
  assert(encode(migrated) == encode(original)); // All former fields, not just the partner.
  FakeNvs::partialWrite = true;
  assert(!GameSaveStorage::save(loaded) && loaded.saveVersion == 1 && loaded.sequence == 41);
  assert(FakeNvs::data.at("pokemon_g1/save_a") == g1);
  FakeNvs::partialWrite = false;
  assert(GameSaveStorage::load(loaded) == LoadResult::Loaded && loaded.saveVersion == 1);
  assert(GameSaveStorage::save(loaded) && loaded.saveVersion == SAVE_VERSION && loaded.sequence == 42);
  assert(FakeNvs::data.at("pokemon_g1/save_a") == g1);
  assert(GameSaveStorage::load(migrated) == LoadResult::Loaded && migrated.saveVersion == SAVE_VERSION);
  assert(encode(loaded) == encode(migrated));
  // Mixed-version slots: corrupted newest v2 recovers original v1, not a new game.
  FakeNvs::data["pokemon_g1/save_b"].back() ^= 1;
  assert(GameSaveStorage::load(loaded) == LoadResult::Loaded && loaded.sequence == 41 && loaded.saveVersion == 1);
  // A higher sequence v1 must also win over a valid older v2.
  FakeNvs::data["pokemon_g1/save_b"] = encode(migrated);
  original.sequence = 43; FakeNvs::data["pokemon_g1/save_a"] = legacyRecord(original);
  assert(GameSaveStorage::load(loaded) == LoadResult::Loaded && loaded.sequence == 43 && loaded.saveVersion == 1);
  std::puts("PASS migration: G1 full party/progress/dex preserved, safe A/B upgrade and failure recovery");
}

int main() { codecTests(); storageTests(); explorationTests(); migrationTests(); }
