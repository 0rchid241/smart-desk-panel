from pathlib import Path
import shutil
src = Path('firmware/smart_desk_esp32')
dst = Path('build/g2-fallback-source/smart_desk_esp32')
shutil.copytree(src, dst, ignore=shutil.ignore_patterns('local_game_assets'), dirs_exist_ok=True)
assert not (dst / 'local_game_assets').exists()
print('Prepared G2 asset-free source. Original assets unchanged.')
